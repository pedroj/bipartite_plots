## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5,
  fig.align = "center"
)

## ----packages, message = FALSE, warning = FALSE-------------------------------
library(ggbipart)
library(ggplot2)
library(network)
library(igraph)

## ----read_data----------------------------------------------------------------
# Nava de las Correhuelas (26 plants x 36 frugivores).
nch <- as.matrix(read.csv(
  system.file("extdata", "sdw01_adj_fru.csv", package = "ggbipart"),
  comment.char = "#", row.names = 1, check.names = FALSE))

# Hato Raton (16 plants x 17 frugivores).
hr <- as.matrix(read.csv(
  system.file("extdata", "sdw02_adj_fru.csv", package = "ggbipart"),
  comment.char = "#", row.names = 1, check.names = FALSE))

dim(nch)
dim(hr)

## ----init_graphs--------------------------------------------------------------
hr.net <- bip_init_network(hr)   # network object
hr.ig  <- bip_init_igraph(hr)    # igraph object

hr.net

## ----helpers------------------------------------------------------------------
head(vectorize(hr))
summary(bip_edgewt(hr, x = 30))

## ----qtplot-------------------------------------------------------------------
bip_qtplot(hr)

## ----binplot------------------------------------------------------------------
bip_binplot(hr, hr.net)

## ----igplot-------------------------------------------------------------------
bip_igplot(hr, hr.ig)

## ----ggnet_basic--------------------------------------------------------------
bip_ggnet(hr.net, hr)

## ----ggnet_styled, message = FALSE, warning = FALSE---------------------------
col <- c("P" = "#FC9272", "A" = "#9ECAE1")
bip_ggnet(hr.net, hr,
          size = 7, shape = "mode", color = "mode",
          palette = col, layout.exp = 0.25) +
  geom_text(aes(label = network.vertex.names(hr.net)),
            color = "black", size = 3) +
  theme(legend.position = "none")

## ----railway, message = FALSE, warning = FALSE--------------------------------
bip_railway(hr, label = TRUE)

## ----session_info-------------------------------------------------------------
sessionInfo()

